﻿using System.Windows;
using SimpleStockApp.Stores;
using SimpleStockApp.ViewModels;

namespace SimpleStockApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            NavigationStore navigationStore = new NavigationStore();
            navigationStore.CurrentViewModel = new StockHomeViewModel(navigationStore);
            DataContext = new MainWindowViewModel(navigationStore);
        }
    }
}