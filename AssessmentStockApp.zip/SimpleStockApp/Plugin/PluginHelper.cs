﻿using ServiceBase;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SimpleStockApp.Plugin
{
    internal class PluginHelper
    {
        private IProviderService _serviceProvider;
        public IProviderService ServiceProvider { 
            get { return _serviceProvider; } 
            set { this._serviceProvider = value; } 
        }

        // PluginHelper: sets the service provider to the specified provider based on name and assembly locations
        public PluginHelper(string pluginName, string[] pluginPaths)
        {
            IEnumerable<IProviderService> providerServices = pluginPaths.SelectMany(pluginPath =>
            {
                Assembly pluginAssembly = LoadPlugin(pluginPath);
                return CreateServices(pluginAssembly);
            }).ToList();

            IProviderService providerService = providerServices.FirstOrDefault(c => c.Name == pluginName);
            if (providerService == null)
            {
                Console.WriteLine("No such provider service is known.");
            }

            ServiceProvider = providerService;
        }

        // LoadPlugin: fetches and returns the assembly based on the relative path to the dll
        static Assembly LoadPlugin(string relativePath)
        {    // Navigate up to the solution root
            string root = Path.GetFullPath(Path.Combine(
                Path.GetDirectoryName(
                    Path.GetDirectoryName(
                        Path.GetDirectoryName(
                            Path.GetDirectoryName(
                                Path.GetDirectoryName(typeof(App).Assembly.Location)))))));

            string pluginLocation = Path.GetFullPath(Path.Combine(root, relativePath.Replace('\\', Path.DirectorySeparatorChar)));
            Console.WriteLine($"Loading commands from: {pluginLocation}");
            PluginLoadContext loadContext = new PluginLoadContext(pluginLocation);
            return loadContext.LoadFromAssemblyName(new AssemblyName(Path.GetFileNameWithoutExtension(pluginLocation)));
        }

        static IEnumerable<IProviderService> CreateServices(Assembly assembly)
        {
            try
            {
                assembly.GetTypes();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            int count = 0;

            foreach (Type type in assembly.GetTypes())
            {
                if (typeof(IProviderService).IsAssignableFrom(type))
                {
                    IProviderService result = Activator.CreateInstance(type) as IProviderService;
                    if (result != null)
                    {
                        count++;
                        yield return result;
                    }
                }
            }

            if (count == 0)
            {
                string availableTypes = string.Join(",", assembly.GetTypes().Select(t => t.FullName));
                throw new ApplicationException(
                    $"Can't find any type which implements IProviderService in {assembly} from {assembly.Location}.\n" +
                    $"Available types: {availableTypes}");
            }
        }
    }
}
