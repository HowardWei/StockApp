﻿using Microsoft.VisualBasic;
using ServiceBase.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SimpleStockApp.Models
{
    internal class StockModel : INotifyPropertyChanged, IStockModel
    {
        #region Field and properties
        public string Ticker { get; set; }
        public string Name { get; set; }
        public DateTime Time { get; set; }
        public ObservableCollection<PriceLog> PriceLogs { get; set; }
        private decimal? price;
        public decimal? Price {
            get 
            {
                return this.price;
            }
            set
            {
                this.price = value;
                OnPropertyChanged();
            }
        }

        private string trendColor { get; set; }
        public string TrendColor
        {
            get
            {
                return this.trendColor;
            }
            set
            {
                this.trendColor = value; 
                OnPropertyChanged();
            }
        }
        #endregion

        #region Constructor
        public StockModel()
        {
            PriceLogs = new ObservableCollection<PriceLog>();
            TrendColor = "Neutral";
        }
        #endregion

        #region Methods
        public void UpdateTrendColor(decimal? price)
        {
            if (PriceLogs.Count == 0 || price == null || price == PriceLogs[0].Price)
            {
                TrendColor = "Neutral";
            } 
            else if (price < PriceLogs[0].Price)
            {
                TrendColor = "Negative";
            } 
            else if (price > PriceLogs[0].Price)
            {
                TrendColor = "Positive";
            }
        }

        // logs price for history view
        public void LogPrice(decimal price)
        {
            PriceLogs.Insert(0, new PriceLog(DateTime.UtcNow, price));
        }
        #endregion

        #region Event handler
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
