﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleStockApp.Models
{
    // PriceLog: represents the date and price log model for a stock at a certain point in time
    internal class PriceLog
    {
        public DateTime Date { get; set; }
        public decimal Price { get; set; }

        public PriceLog(DateTime date, decimal price) 
        {
            Date = date;
            Price = price;
        }
    }
}
