﻿using SimpleStockApp.Commands;
using SimpleStockApp.Models;
using SimpleStockApp.Stores;

namespace SimpleStockApp.ViewModels
{
    internal class StockHistoryViewModel : ViewModelBase
    {
        #region Fields and properties
        private NavigationStore _navigationStore;
        private StockHomeViewModel _stockHomeViewModel;
        private StockModel selectedStock;
        public StockModel SelectedStock { 
            get { return selectedStock; } 
            set { selectedStock = value;
                OnPropertyChanged();
            }
        }
        #endregion

        #region Commands
        public RelayCommand StockHomeViewCommand => new RelayCommand(execute => NavigateToStockHomeView());
        #endregion

        #region Constructors
        public StockHistoryViewModel(StockHomeViewModel stockHomeViewModel, NavigationStore navigationStore, StockModel stock) 
        {
            // passing in this reference so we can go back to the same instance of the viewmodel
            _stockHomeViewModel = stockHomeViewModel;
            _navigationStore = navigationStore;
            SelectedStock = stock;
        }
        #endregion

        #region Methods
        private void NavigateToStockHomeView()
        {
            _navigationStore.CurrentViewModel = _stockHomeViewModel;
        }
        #endregion
    }
}
