﻿using ServiceBase;
using ServiceBase.Models;
using SimpleStockApp.Commands;
using SimpleStockApp.Models;
using SimpleStockApp.Plugin;
using SimpleStockApp.Stores;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleStockApp.ViewModels
{
    internal class StockHomeViewModel : ViewModelBase
    {
        #region Fields and properties
        private string trendColor;
        public string TrendColor
        {
            get { return this.trendColor; }
            set 
            { 
                this.trendColor = value;
                OnPropertyChanged();
            }
        }
        private IProviderService _stockProvider;
        public ObservableCollection<StockModel> Stocks { get; set; }
        public ObservableCollection<StockModel> SubscribedStocks { get; set; }
        private StockModel selectedStock;
        public StockModel SelectedStock
        {
            get { return this.selectedStock; }
            set
            {
                this.selectedStock = value;
                OnPropertyChanged();
            }
        }
        private StockModel selectedSubscribedStock;
        public StockModel SelectedSubscribedStock
        {
            get { return this.selectedSubscribedStock; }
            set
            {
                this.selectedSubscribedStock = value;
                OnPropertyChanged();
            }
        }
        private NavigationStore _navigationStore;
        #endregion

        #region Commands
        public RelayCommand SubscribeStockCommand => new RelayCommand(execute => SubscribeStock(), canExecute => CanSubscribeStock());
        public RelayCommand UnsubscribeStockCommand => new RelayCommand(execute => UnsubscribeStock(), canExecute => CanUnsubscribeStock());
        public RelayCommand StockHistoryViewCommand => new RelayCommand(execute => NavigateToStockHistoryView());
        #endregion

        #region Methods
        public StockHomeViewModel(NavigationStore navigationStore)
        {
            Stocks = new ObservableCollection<StockModel>();
            SubscribedStocks = new ObservableCollection<StockModel>();
            _navigationStore = navigationStore;

            // start the provider async stream
            StartProviderStream();
        }

        // StartProviderStream: calls async function on provider side to start generating stream of stock prices
        private async Task StartProviderStream()
        {
            // pluginPaths can be set during runtime with the appropriate controls
            string[] pluginPaths = new string[]
            {
                @"SimpleStockAppDLL\bin\Debug\net8.0-windows\SimpleStockAppProvider.dll"
            };

            // provider can then be selected at runtime as well through its name
            _stockProvider = (new PluginHelper("SimpleStockProvider", pluginPaths)).ServiceProvider;

            Dictionary<string, string> availableStocks = _stockProvider.GetAvailableStocks();
            StockModel stock;
            foreach (KeyValuePair<string, string> availableStock in availableStocks)
            {
                stock = new StockModel();
                stock.Ticker = availableStock.Key;
                stock.Name = availableStock.Value;
                Stocks.Add(stock);
            }

            await foreach (List<IStockModel> stockResponse in _stockProvider.GetStockPricesAsync())
            {
                foreach (var currentStock in stockResponse)
                {
                    var thisStock = SubscribedStocks.Where(stock => stock.Ticker == currentStock.Ticker).FirstOrDefault();
                    if (thisStock == null) continue;

                    thisStock.UpdateTrendColor(currentStock.Price);
                    thisStock.LogPrice((decimal)currentStock.Price);
                    thisStock.Price = currentStock.Price;
                }
            }
        }

        // add stock to list of subscribed stocks and starts generating prices for that stock
        private void SubscribeStock()
        {
            selectedStock.Price = null;
            SubscribedStocks.Add(selectedStock);
            _stockProvider.SubscribeStock(selectedStock.Ticker);
        }

        // CanExecute function for SubscribeStock command
        private bool CanSubscribeStock()
        {
            return selectedStock != null && !SubscribedStocks.Contains(selectedStock);
        }


        // remove stock from list of subscribed stocks and stops generating prices for that stock
        private void UnsubscribeStock()
        {
            SubscribedStocks.Remove(selectedStock);
            _stockProvider.UnsubscribeStock(selectedStock.Ticker);
        }

        // CanExecute function for UnsubscribeStock command
        private bool CanUnsubscribeStock()
        {
            return selectedStock != null && SubscribedStocks.Contains(selectedStock);
        }

        private void NavigateToStockHistoryView()
        {
            _navigationStore.CurrentViewModel = new StockHistoryViewModel(this, _navigationStore, SelectedSubscribedStock);
        }
        #endregion
    }
}
