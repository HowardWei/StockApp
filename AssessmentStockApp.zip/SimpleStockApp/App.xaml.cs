﻿using ServiceBase;
using SimpleStockApp.Plugin;
using System.Configuration;
using System.Configuration.Provider;
using System.Data;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Input;

namespace SimpleStockApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
        }
    }
}
