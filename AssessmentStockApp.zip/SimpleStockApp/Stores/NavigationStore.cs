﻿using SimpleStockApp.ViewModels;

namespace SimpleStockApp.Stores
{
    internal class NavigationStore
    {
        public event Action CurrentViewModelChanged;

        private ViewModelBase currentViewModel;
        public ViewModelBase CurrentViewModel 
        {
            get
            {
                return currentViewModel;
            }
            set
            {
                currentViewModel = value;
                CurrentViewModelChanged?.Invoke();
            }
        }
    }
}
