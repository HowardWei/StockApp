﻿using ServiceBase.Models;

namespace SimpleStockAppProvider.Models
{
    public class StockModel : IStockModel
    {
        public string Ticker { get; set; }
        public string Name { get; set; }
        public decimal? Price { get; set; }
        public DateTime Time { get; set; }
    }
}
