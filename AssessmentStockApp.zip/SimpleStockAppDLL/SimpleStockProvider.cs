using ServiceBase;
using ServiceBase.Models;
using SimpleStockAppProvider.Models;

namespace SimpleStockAppDLL
{
    public class SimpleStockProvider : IProviderService
    {
        private const string STOCK1_TICKER = "Stock1";
        private const string STOCK2_TICKER = "Stock2";

        public string Name => "SimpleStockProvider";

        // instead of database, will hold stock information held by this service in a simple dictionary
        private readonly Dictionary<string, string> availableStocks = new Dictionary<string, string> 
        {
            { STOCK1_TICKER, "Stock 1"},
            { STOCK2_TICKER, "Stock 2"}
        };
        List<string> SubscribedStocks = new List<string>();

        // GetAvailableStocks: returns the list of stocks available with this service
        public Dictionary<string, string> GetAvailableStocks()
        {
            return availableStocks;
        }

        // SubscribeStock: Adds ticker passed as parameter to list of subscribed stocks
        public void SubscribeStock(string ticker)
        {
            SubscribedStocks.Add(ticker);
        }

        // UnsubscribeStock: Removes ticker passed as parameter from list of subscribed stocks
        public void UnsubscribeStock(string ticker)
        {
            SubscribedStocks.Remove(ticker);
        }

        // GetStockPricesAsync: Returns the stock prices for stocks that have had their tickers subscribed
        public async IAsyncEnumerable<List<IStockModel>> GetStockPricesAsync()
        {
            int loops = 0;
            List<IStockModel> stockPrices;
            StockModel stock;

            // upper bound the loop to only generate 1000 ticks for sanity
            while (true && loops <= 1000)
            {
                stockPrices = new List<IStockModel>();
                for (int i = 0; i < SubscribedStocks.Count; i++)
                {
                    stock = new StockModel() 
                    { 
                        Name = availableStocks[SubscribedStocks[i]], 
                        Ticker = SubscribedStocks[i],
                        Price = GenerateStockPrice(SubscribedStocks[i]),
                        Time = DateTime.UtcNow,
                    };
                    stockPrices.Add(stock);
                }
                yield return stockPrices;
                await Task.Delay(1000);
                loops++;
            }
        }

        // GenerateStockPrice: Generates stock price based on given stock id, contains business      
        //                     logic/rules for how each stock should behave
        // stockId: 1 -> Stock1, 2 -> Stock2
        private decimal GenerateStockPrice(string stockTickers)
        {
            if (stockTickers == STOCK1_TICKER)
            {
                return RandomPrice(240, 270); // stock1 price range between 240 and 270
            } 
            else if (stockTickers == STOCK2_TICKER) 
            {
                return RandomPrice(180, 210); // stock2 price range between 180 and 210
            }
            else
            {
                return -1;
            }
        }

        // RandomPrice: Generates random decimal in range
        // startRange: lower limit of stock price
        // endRange: upper limit of stock price
        private decimal RandomPrice(double startRange, double endRange)
        {
            Random random = new Random();
            return decimal.Round((decimal)(random.NextDouble() * Math.Abs(endRange - startRange) + startRange), 2);
        }
    }
}
