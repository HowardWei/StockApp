﻿using ServiceBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceBase
{
    // IProviderService: base interface to be implemented by other provider plugins
    public interface IProviderService
    {
        #region Properties
        // Name: string identifier to lookup a service provider at runtime
        string Name { get; }
        #endregion

        #region Methods
        // GetAvailableStocks: returns a list of available stocks associated with that provider
        Dictionary<string, string> GetAvailableStocks();
        // GetStockPricesAsync: starts async stream of stock prices from provider to subscriber
        IAsyncEnumerable<List<IStockModel>> GetStockPricesAsync();
        // SubscribeStock: adds stock to list of stocks that provider generates prices for
        void SubscribeStock(string ticker);
        // UnsubscribeStock: removes stock from list of stocks that provider generates prices for
        void UnsubscribeStock(string ticker);
        #endregion
    }
}
