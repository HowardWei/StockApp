﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceBase.Models
{
    // IStockModel: interface for provider-to-subscriber data models
    public interface IStockModel
    {
        #region properties
        // Ticker: string indentifier for stock
        public string Ticker { get; set; }
        // Name: full stock name
        public string Name { get; set; }
        // Price: current price of stock
        public decimal? Price { get; set; }
        // Time: time of latest tick
        public DateTime Time { get; set; }
        #endregion
    }
}
